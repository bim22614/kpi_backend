users = [
    {"name": "John Doe"},
    {"name": "Oliver Jr"},
]
categories = {
    1: {"name": "Food"},
    2: {"name": "Transport"},
    3: {"name": "Housing"},
}
records = {
    1: {
        "user_id": 1,
        "category_id": 1,
        "created_at": "2023-07-20T12:00:00",
        "sum": 100,
    },
    2: {
        "user_id": 2,
        "category_id": 2,
        "created_at": "2023-07-21T13:00:00",
        "sum": 200,
    },
}